#!/usr/bin/python

import os
import re
import time
import sys
from threading import Thread

class Ping(Thread):
    lifeline = re.compile(r"(\d) received")
    def __init__ (self,ip):
	Thread.__init__(self)
	self.ip = ip
	self.status = -1
   
    def run(self):
	(stdin, pingcmd, stderr) = os.popen3("ping -w1 -q -c2 "+self.ip,"r")
	while 1:
	    line = pingcmd.readline()
	    if not line: 
		break
	    igot = re.findall(Ping.lifeline,line)
	    if igot:
		self.status = int(igot[0])

class Pinger(Thread):
    def __init__(self, ips, logfile):
	Thread.__init__(self)
	self.ip_groups = {}
	for id, ip_list in ips.items():
	    self.ip_groups[id] = dict([(ip,None) for ip in ip_list])
	self.logfile = logfile
	self.ip_groups_names = self.ip_groups.keys()

    def run(self):
	self.run = True
	self.logfile.write("time,%s\n" % ",".join(self.ip_groups_names))
	while self.run:
	    begin = time.time()
	    for ip_group in self.ip_groups.values():
		for ip in ip_group:
		    ip_group[ip] = Ping(ip)
		    ip_group[ip].start()

	    ping_count = {}
	    for group in self.ip_groups:
		ping_count[group]=0
		for ping in self.ip_groups[group].values():
		    ping.join()
		    if ping.status in (1,2):
			ping_count[group] += 1

	    self.logfile.write("%i," % int(begin))
	    self.logfile.write(",".join([`ping_count[group]` for group in self.ip_groups_names]))
	    self.logfile.write("\n")
	    self.logfile.flush()
	    now = time.time()
	    diff = now - begin
	    if diff < 3:
	        time.sleep(3 - diff)
	self.logfile.close()

    def stop(self):
	self.run = False
