#!/usr/bin/python

from optparse import OptionParser
import ConfigParser
import sys
import os
import os.path
import pickle

# In each experiment we submit two leases: a best-effort lease and an AR lease
# These options specify the contents of the HAIZEA parameter given to OpenNebula
HAIZEA_AR_OPT = """[START="+00:15:00",DURATION="00:05:00",PREEMPTIBLE="no",GROUP="AR"]"""
HAIZEA_BE_OPT = """[START="best_effort",DURATION="00:20:00",PREEMPTIBLE="yes",GROUP="BE"]"""

# Number of cores per physical node
CORES = 8

# Number of VMs per physical node to test
PERNODE = [1,2,4,8]

# Maximum number of VMs to deploy
MAX_VMS = 32

# Path for the VM images for the AR lease
AR_IMAGES_PATH = "/images/ar"
# Inside the above directory, each VM has a directory
# for each VM (each directory has a disk and swap image;
# their filenames are specified in the DISK and SWAP
# variables below). Each directory has the following
# prefix:
AR_PREFIX = "ar-"

# Same as above, but for the best-effort lease
BE_IMAGES_PATH = "/images/besteffort"
BE_PREFIX = "besteffort-"

# VM subnet
IP_BASE="192.168.5"
# AR VM IPs start at IP_BASE.IP_AR_START
IP_AR_START=150
# Best-effort VM IPs start at IP_BASE.IP_BE_START
IP_BE_START=200

# Name of disk images
DISK = "disk.img"
SWAP = "swap.img"

# Return a two digit representation of a number
def twodigitize(num):
    return str(num).rjust(2,"0")

# Common OpenNebula options for all VMs
def get_common_opts():
    opts = """
OS = [kernel = "/vmlinuz", initrd = "/initrd.img", root = "sda1" ]
NIC = [mac=""]
    """
    return opts

# OpenNebula DISK options given path (e.g., AR_IMAGES_PATH)
# a prefix (e.g., AR_PREFIX) and a VM number
def get_disks(path, prefix, number):
    number = twodigitize(number)
    opts = """
DISK=[ SOURCE="%s/%s%s/%s",TARGET="sda1", readonly="no"]
DISK=[ SOURCE="%s/%s%s/%s",TARGET="sda2", readonly="no"]
    """ % (path, prefix, number, DISK, path, prefix, number, SWAP)
    return opts

# Each experiment configuration has a name based on
# (1) Are we suspending to local or global fs?
# (2) Memory per VM
# (3) Number of VMs per node
def get_dir_name(localglobal, mem, pernode):
    return "%s_%sMB_%sVMpernode" % (localglobal, mem, pernode)

parser = OptionParser()

# Memory (in MB) per VM
parser.add_option("-m", "--memory", action="store", type="int", dest="memory")

# Where to create the configuration files
parser.add_option("-d", "--dir", action="store", type="string", dest="dir")

# Template for Haizea configuration file
parser.add_option("-z", "--haizea", action="store", type="string", dest="haizea")
(opts, args) = parser.parse_args()

num = MAX_VMS
mem = opts.memory
basedir = opts.dir 
haizea_template = opts.haizea

for localglobal in ["local", "global"]:
    for pernode in PERNODE:
	# Create directory
        confdir = "%s/%s" % (basedir, get_dir_name(localglobal, mem, pernode))

        if not os.path.exists(confdir):
	    os.mkdir(confdir)    

	cpus = CORES / pernode

	ips = {}

	# Create templates for AR
	for i in range(num):
	    n = i + 1

	    one_template = get_common_opts() + get_disks(AR_IMAGES_PATH, AR_PREFIX, n) 
	    one_template += "\n"
	    one_template += "MEMORY = %i\n" % mem
	    one_template += "CPU = %i\n" % cpus
	    one_template = one_template + "HAIZEA = %s\n" % HAIZEA_AR_OPT + "NAME = AR-%i\n" % n

	    filename = "%s/ar-%s.one" % (confdir, twodigitize(n))

	    templ_file = open(filename, "w")
	    templ_file.write(one_template)
	    templ_file.close()

	# Add IPs for AR VMs
	ips["AR"] = ["%s.%i" % (IP_BASE, IP_AR_START+n) for n in range(num) ]

	# Create templates for BE
	for i in range(num):
	    n = i + 1

	    one_template = get_common_opts() + get_disks(BE_IMAGES_PATH, BE_PREFIX, n) 
	    one_template += "\n"
	    one_template += "NAME = BE-%i\n" % n
	    one_template += "MEMORY = %i\n" % mem
	    one_template += "CPU = %i\n" % cpus
	    one_template += "HAIZEA = %s\n" % HAIZEA_BE_OPT

	    filename = "%s/be-%s.one" % (confdir, twodigitize(n))

	    templ_file = open(filename, "w")
	    templ_file.write(one_template)
	    templ_file.close()

	# Add IPs for BE VMs
	ips["BE"] = ["%s.%i" % (IP_BASE, IP_BE_START+n) for n in range(num) ]

	# Create Haizea file
	haizea_template_file = open (haizea_template, "r")
	c = ConfigParser.ConfigParser()
	c.readfp(haizea_template_file)
	haizea_template_file.close()

        c.set("scheduling", "suspendresume-exclusion", localglobal)
        c.set("scheduling", "scheduling-threshold-factor", 0)
        if localglobal == "global":
	    c.set("scheduling", "suspend-rate", 65)
	    c.set("scheduling", "resume-rate", 65)
	elif localglobal == "local":
	    c.set("scheduling", "suspend-rate", 55)
	    c.set("scheduling", "resume-rate", 55)

        haizea_filename = "%s/haizea.conf" % confdir
        haizea_file = open(haizea_filename, "w")
        c.write(haizea_file)
        haizea_file.close()

        # Save IP file
        ip_file = open("%s/ips" % confdir, "w")
        pickle.dump(ips, ip_file)
        ip_file.close()

