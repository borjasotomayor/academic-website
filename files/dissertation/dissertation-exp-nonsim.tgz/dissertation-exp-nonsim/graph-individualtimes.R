#!/usr/bin/Rscript --vanilla

library(lattice)

xen <- read.table("data_processed/xen_raw.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)
xen$MEM <- factor(xen$MEM)
xen$PERNODE <- factor(xen$PERNODE)

pdf("graphs/graph-individualtimes-suspend.pdf", width=6, height=4, pointsize=6)

bwplot(suspend ~ MEM |  PERNODE + FS, auto.key=TRUE, scales=list(x=list(relation='same'), y=list(relation='same')), data=xen, ylim=c(0,40), ylab="Time to suspend a single VM")

pdf("graphs/graph-individualtimes-resume.pdf", width=6, height=4, pointsize=6)
bwplot(resume ~ MEM |  PERNODE + FS, auto.key=TRUE, scales=list(x=list(relation='same'), y=list(relation='same')), data=xen, ylim=c(0,40), ylab="Time to resume a single VM")

