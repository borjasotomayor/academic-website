#!/usr/bin/Rscript --vanilla

SUSP_RATE <- list(local=61.86, global=63.67)
RESM_RATE <- list(local=66.27, global=81.27)
ENACT <- 2

ping.raw <- read.table("data_processed/ping_raw.csv", header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

predict <- function(fs, pernode, N, mem, rate)
{
	if (fs == "global")
		return (N*ENACT + N * mem/rate)
	else if (fs=="local")
		return (N*ENACT + pernode * mem/rate)
}

ping.raw$susp_predicted  <- NA
ping.raw$resm_predicted  <- NA
for (i in 1:nrow(ping.raw))
{
    fs <- ping.raw[i,]$FS
    pernode <- ping.raw[i,]$PERNODE
    mem <- ping.raw[i,]$MEM
    N <- ping.raw[i,]$N_VMs
    
    ping.raw[i,]$susp_predicted <- predict(fs, pernode, N, mem, SUSP_RATE[[fs]])
    ping.raw[i,]$resm_predicted <- predict(fs, pernode, N, mem, SUSP_RATE[[fs]])
}

ping.raw$susp_accuracy <- ping.raw$SUSPENDING_BE / ping.raw$susp_predicted 
ping.raw$resm_accuracy <- ping.raw$RESUMING_BE / ping.raw$resm_predicted 


ping.mean <- aggregate(data.frame(ping.raw$SUSPENDING_BE, ping.raw$RESUMING_BE, ping.raw$susp_accuracy, ping.raw$resm_accuracy), by=list(FS=ping.raw$FS,MEM=ping.raw$MEM,PERNODE=ping.raw$PERNODE), mean)
ping.sd <- aggregate(data.frame(ping.raw$SUSPENDING_BE, ping.raw$RESUMING_BE, ping.raw$susp_accuracy, ping.raw$resm_accuracy), by=list(FS=ping.raw$FS,MEM=ping.raw$MEM,PERNODE=ping.raw$PERNODE), sd)

ping <- data.frame(FS=ping.mean$FS, MEM=ping.mean$MEM, PERNODE=ping.mean$PERNODE, 
                   susp_avg=ping.mean$ping.raw.SUSPENDING_BE, susp_stdev=ping.sd$ping.raw.SUSPENDING_BE, 
                   suspacc_avg=ping.mean$ping.raw.susp_accuracy, suspacc_stdev=ping.sd$ping.raw.susp_accuracy,
                   resm_avg=ping.mean$ping.raw.RESUMING_BE, resm_stdev=ping.sd$ping.raw.RESUMING_BE,
                   resmacc_avg=ping.mean$ping.raw.resm_accuracy, resmacc_stdev=ping.sd$ping.raw.resm_accuracy
                   )

ping$MEM <- factor(ping$MEM)
ping$PERNODE <- factor(ping$PERNODE)

ping <- ping[order(ping$FS,ping$MEM),]

genGraph <- function(filename, data, x, xlab, y, ylab, ylim=NONE, mar, xaxis="s", yaxis="s")
{
	par(mar=mar)
	plot.default(data[[x]], data[[y]], type="n", main="", xlab=xlab, ylab=ylab, xaxt="n", yaxt = yaxis, ylim=ylim)

	if(xaxis!="n")
		axis(1, at=1:nlevels(data[[x]]), labels=levels(data[[x]])) 

	cols<-c("blue","brown")
	lty<-c(1,2)
	col <- 1

	for ( fs in levels(data$FS) )
	{
		pch = 1
		for ( pernode in levels(data$PERNODE) )
		{
			data2 <- subset(data, FS == fs & PERNODE == pernode)
			points(data2[[x]], data2[[y]], col=cols[col], pch=pch)
			lines(data2[[x]], data2[[y]], col=cols[col], lty=lty[col])
			pch <- pch + 1
		}
		col <- col + 1
	}

}

pdf("graphs/suspendresume_timeaccuracy.pdf", width=6, height=4, pointsize=11)
par(mfrow=c(2,3), mar=c(3,3,3,3))
genGraph("foobar", ping, "MEM", "MEM", "susp_avg", "Time (s)", ylim=c(0,650), mar = c(0, 4, 1, 1), xaxis="n")
genGraph("foobar", ping, "MEM", "MEM", "resm_avg", "Time (s)", ylim=c(0,650), mar = c(0, 0, 1, 1), xaxis="n", yaxis="n")
plot.new()

genGraph("foobar", ping, "MEM", "Suspension (MB of memory per VM)", "suspacc_avg", "Accuracy", ylim=c(0.4,1.7), mar = c(4, 4, 1, 1))
genGraph("foobar", ping, "MEM", "Resumption (MB of memory per VM)", "resmacc_avg", "Accuracy", ylim=c(0.4,1.7), mar = c(4, 0, 1, 1), yaxis="n")

plot.new()
cols<-c("blue","brown")
legcols<-c(rep(cols[1],nlevels(ping$PERNODE)), rep(cols[2],nlevels(ping$PERNODE)))
ping$title <- paste(ping$FS, ", ", ping$PERNODE, " VMs per node", sep="")
legtitle <- c("1 VM per node", "2 VMs per node", "4 VMs per node", "8 VMs per node", "Global filesystem", "Local filesystem")
legend(x="topleft", legend=legtitle, col=c("black","black","black","black","blue","brown"), pch=c(1,2,3,4,NA,NA), lty=c(0,0,0,0,1,2))


