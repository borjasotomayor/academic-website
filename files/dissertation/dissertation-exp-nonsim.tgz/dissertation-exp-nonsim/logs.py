#!/usr/bin/python

import sys
import os
import re
from tempfile import mkdtemp
from subprocess import call
from mx import DateTime
from mx.DateTime import Parser

start_suspend_re = re.compile("\[([0-9\-]+ [0-9:]+).*Suspending ([0-9]+).*")
end_suspend_re = re.compile("\[([0-9\-]+ [0-9:]+).*destroyDomain\(([0-9]+)\).*")
start_resume_re = re.compile("\[([0-9\-]+ [0-9:]+).*restore\(\['domain', \['domid', '([0-9]+)'.*'name', '([^']+)'.*")
end_resume_re1 = re.compile(".*XendDomainInfo.completeRestore$")
end_resume_re2 = re.compile("\[([0-9\-]+ [0-9:]+).*Storing domain details:.*'name': '([^']+)'.*")


def get_xenlog_date(line):
    if line[0] != "[":
	raise
    fields = line.split()
    timestamp_str = fields[0][1:] + " " + fields[1]
    return Parser.DateTimeFromString(timestamp_str)

def get_onelog_date(line):
    fields = line.split()
    timestamp_str = " ".join(fields[0:5])
    return Parser.DateTimeFromString(timestamp_str)

def filter_logfile(logf, start, date_getter):
    log = open(logf)

    are_we_there_yet = False

    newfile = []

    for line in log:
	if not are_we_there_yet:
	    try:
		timestamp = date_getter(line)
		if timestamp > start:
    		    are_we_there_yet = True
	    except Exception, e:
		pass
        if are_we_there_yet:
	    newfile.append(line)

    log.close()

    return newfile

def get_xen_logs(start, hosts, outdir):
    tempdir = mkdtemp()
    for host in hosts:
	logfile = "%s/xend.%s.log"% (tempdir, host)
        filtered_logfile = "%s/xend.%s.log"% (outdir, host)
	call(["ssh", host, "cat `ls -r /var/log/xen/xend.log*` > /tmp/xend.log"])
	call(["scp", "%s:/tmp/xend.log" % host, logfile])
        filtered_logs = filter_logfile(logfile, start, get_xenlog_date)
        filtered_logfilef = open(filtered_logfile, "w")
        filtered_logfilef.writelines(filtered_logs)
        filtered_logfilef.close()
        os.remove(logfile)

    os.rmdir(tempdir)

def get_one_log(start, outdir):
    logfile = "/home/borja/one/var/oned.log"
    filtered_logfile = "%s/oned.log"% outdir
    filtered_logs = filter_logfile(logfile, start, get_onelog_date)
    filtered_logfilef = open(filtered_logfile, "w")
    filtered_logfilef.writelines(filtered_logs)
    filtered_logfilef.close()
    

def start_iostat_log(hosts):
    for host in hosts:
	call(["ssh", "-f", host, "/home/borja/bin/iostat_log.py"])

def start_xentop_log(hosts):
    for host in hosts:
	call(["ssh", "-f", host, "/home/borja/bin/xentop_log.py"])

def get_iostat_log(hosts, outdir):
    for host in hosts:
	call(["ssh", host, "pkill ""iostat$"""])
	logfile = "%s/iostat.%s.log"% (outdir, host)
	call(["scp", "%s:/var/tmp/iostat.log" % host, logfile])

def get_xentop_log(hosts, outdir):
    for host in hosts:
	logfile = "%s/xentop.%s.log"% (outdir, host)
	call(["scp", "%s:/var/tmp/xentop.log" % host, logfile])
	call(["ssh", host, "pkill xentop"])


#start_ticks=1223490480
#start = DateTime.TimestampFromTicks(start_ticks)
#get_xen_logs(start, "/tmp/logs")
#get_one_log(start, "/tmp/logs")
