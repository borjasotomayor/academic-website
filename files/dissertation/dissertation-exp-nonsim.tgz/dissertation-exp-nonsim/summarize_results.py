#!/usr/bin/python

import sys
import os
import os.path
import re
from math import sqrt

from optparse import OptionParser
from mx.DateTime import ISO, TimeDelta
from mx import DateTime
from operator import itemgetter

def avgstdev(nums):
    avg = float(sum(nums)) / len(nums)
    stdev = sqrt(sum([(x - avg)**2 for x in nums])/len(nums))
    return avg, stdev

parser = OptionParser()
parser.add_option("-d", "--directory", dest="dir")
(options, args) = parser.parse_args()

dirs = os.listdir(options.dir)
dirs.sort()

####
####  Ping data
####

ping_raw = open("data_processed/ping_raw.csv", "w")
ping_avg = open("data_processed/ping_avg.csv", "w")

state_names = ["BOOTING_BE","RUNNING_BE_1","SUSPENDING_BE","BOOTING_AR","RUNNING_AR","RESUMING_BE","RUNNING_BE_2"]

header = "FS,MEM,PERNODE,N_VMs,run," + ",".join(state_names)

print >>ping_raw, header
state_names_avg = []
for s in state_names:
    state_names_avg.append(s + "_avg")
    state_names_avg.append(s + "_stdev")
header = "FS,MEM,PERNODE,N_VMs," + ",".join(state_names_avg)
print >>ping_avg, header

num = {}
keys = []
for resultdir in dirs:
    pingfile = "%s/%s/ping" % (options.dir, resultdir)
    startfile = "%s/%s/start" % (options.dir, resultdir)

    if os.path.exists(pingfile):
        (profile, run) = resultdir.split(".")

	if len(run) > 1:
	    continue # This is a directory that is running or has been killed

        (localglobal, mem, vmspernode) = profile.split("_")
	vms = int(vmspernode[0]) * 4
	mem = int(mem[:-2])

	key = (localglobal,mem,vmspernode)
	if not num.has_key(key):
	    num[key] = {}
	    keys.append(key)

	startfile = open(startfile)
	starttime = ISO.ParseDateTime(startfile.readline())
	startfile.close()

	pingfilef = open(pingfile)
	pingfilef.readline() # Ignore header line
	pings = []
	for ping in pingfilef:
	    fields = ping.strip().split(",")
	    pings.append((DateTime.TimestampFromTicks(int(fields[0])), int(fields[1]), int(fields[2]))) # Date, BE, AR
	pingfilef.close()
	
	states = dict([(s,-1) for s in state_names])

	prev_state_change = starttime + TimeDelta(seconds=10)
	state = "BOOTING_BE"

	def end_state(state, time):
	    global prev_state_change
	    states[state] = int((time - prev_state_change).seconds)
	    prev_state_change = time

	for ping in pings:
	    time = ping[0]
	    be = ping[1]
	    ar = ping[2]
	    if state == "BOOTING_BE" and be == vms:
		end_state(state, time)
		state = "RUNNING_BE_1"
	    elif state == "RUNNING_BE_1" and be < vms:
		end_state(state, prev_time)
		state = "SUSPENDING_BE"
	    elif state == "SUSPENDING_BE" and be == 0:
		end_state(state, time)
		state ="BOOTING_AR"
	    elif state == "BOOTING_AR" and ar == vms:
		end_state(state, time)
		state ="RUNNING_AR"
	    elif state == "RUNNING_AR" and ar == 0:
		end_state(state, time)
		state ="RESUMING_BE"
	    elif state == "RESUMING_BE" and be == vms:
		end_state(state, time)
		state ="RUNNING_BE_2"
	    elif state == "RUNNING_BE_2" and be == 0:
		end_state(state, time)
		state ="DONE"

	    prev_time = time

	# The pinger sometimes stops before all the BE VMs have stopped
	if state == "RUNNING_BE_2":
	    end_state(state, prev_time)
	    state = "DONE"

	if state != "DONE":
	    sys.stderr.write('Unexpected ending state (%s) in %s\n' % (state, resultdir) ) 

	line = ",".join([localglobal,`mem`,vmspernode[0],`vms`, run]) + ","
	line += ",".join(`states[s]` for s in state_names)
	print >> ping_raw, line

	for s in state_names:
	    key = (localglobal,mem,vmspernode)
	    num[key].setdefault(s, []).append(states[s])

for k in keys:
    localglobal,mem,vmspernode = k
    vms = int(vmspernode[0]) * 4
    line = ",".join([localglobal,`mem`,vmspernode[0],`vms`])
    for s in state_names:
	avg, stdev = avgstdev(num[k][s])
        line += ",%.2f,%.2f" %(avg, stdev)
    print >> ping_avg, line
    

ping_raw.close()
ping_avg.close()

####
####  Xen logfile data
####

xen_raw = open("data_processed/xen_raw.csv", "w")
xen_avg = open("data_processed/xen_avg.csv", "w")
xen_stats = open("data_processed/xen_stats.csv", "w")

header = "FS,MEM,PERNODE,N_VMs,run,suspend,resume"

print >>xen_raw, header

header = "FS,MEM,PERNODE,N_VMs,suspend_avg,suspend_stdev,resume_avg,resume_stdev"
print >>xen_avg, header

header = "FS,MEM,PERNODE,N_VMs,run,suspending,susp_contend,susp_interval,resuming,resume_contend,resume_interval"
print >>xen_stats, header

susp = {}
resm = {}
keys = []

start_suspend_re = re.compile("\[([0-9\-]+ [0-9:]+).*Suspending ([0-9]+).*")
end_suspend_re = re.compile("\[([0-9\-]+ [0-9:]+).*destroyDomain\(([0-9]+)\).*")

start_resume_re = re.compile("\[([0-9\-]+ [0-9:]+).*restore\(\['domain', \['domid', '([0-9]+)'.*'name', '([^']+)'.*")
end_resume_re = re.compile("\[([0-9\-]+ [0-9:]+).*Storing domain details:.*'name': '([^']+)'.*")

for resultdir in dirs:
    print resultdir
    dir = "%s/%s" % (options.dir, resultdir)
    xenlogs = ["%s/%s" % (dir,f) for f in os.listdir(dir) if f.startswith("xend")]
    if len(xenlogs)>0:
	xenlogs.sort()

        (profile, run) = resultdir.split(".")

	if len(run) > 1:
	    continue # This is a directory that is running or has been killed

        (localglobal, mem, vmspernode) = profile.split("_")
	vmspernode = int(vmspernode[0])
	vms = vmspernode * 4
	mem = int(mem[:-2])

	key = (localglobal,mem,vmspernode)
	if not susp.has_key(key):
	    susp[key] = []
	    resm[key] = []
	    keys.append(key)

	for xenlog in xenlogs:
	    xen_domains={}
	    name2dom={}
	    xenlogf = open(xenlog)
	    for line in xenlogf:
    		# We can either start suspending or resuming
		match = start_suspend_re.match(line)
		if match:
		    time = ISO.ParseDateTime(match.group(1))
		    domain = int(match.group(2))
		    xen_domains[domain] = [time,None,None,None]
		    continue

	        match = end_suspend_re.match(line)
	        if match:
	    	    time = ISO.ParseDateTime(match.group(1))
		    domain = int(match.group(2))
		    if xen_domains.has_key(domain):
			xen_domains[domain][1] = time
		    continue

		match = start_resume_re.match(line)
		if match:
		    time = ISO.ParseDateTime(match.group(1))
		    domain = int(match.group(2))
		    name = match.group(3)
		    name2dom[name] = domain #Otherwise, no way of knowing when resume ended
		    if xen_domains.has_key(domain):
			xen_domains[domain][2] = time
		    continue

		match = end_resume_re.match(line)
		if match:
		    time = ISO.ParseDateTime(match.group(1))
		    name = match.group(2)
		    if name2dom.has_key(name):
			domain = name2dom[name]
			if xen_domains.has_key(domain):
			    xen_domains[domain][3] = time
	    
	    if len(xen_domains) == 0:
		continue
	    start_suspL = []
	    end_suspL = []
	    start_resmL = []
	    end_resmL = []
	    for (start_susp, end_susp, start_resm, end_resm) in xen_domains.values():
		suspend_time = int((end_susp - start_susp).seconds)
		resume_time = int((end_resm - start_resm).seconds)
		line = ",".join([localglobal,`mem`,`vmspernode`,`vms`, run]) + ","
		line += `suspend_time` + "," + `resume_time`
		print >> xen_raw, line

		susp[key].append(suspend_time)
		resm[key].append(resume_time)

		start_suspL.append(start_susp)
		end_suspL.append(end_susp)
		start_resmL.append(start_resm)
		end_resmL.append(end_resm)

	    start_suspL.sort()
	    end_suspL.sort()
	    start_resmL.sort()
	    end_resmL.sort()

	    suspend_time = int((end_suspL[-1] - start_suspL[0]).seconds)
	    resume_time = int((end_resmL[-1] - start_resmL[0]).seconds)

	    def get_intervals_overlaps(times):
		times.sort(key=itemgetter(0))
		overlap = 0
		intervals = []
		prev_start = None
		prev_end = None
		for i,(start, end) in enumerate(times):
		    if i+1 < len(times):
    			overlap = 0
			for (start2, end2) in times[i+1:]:
			    if end < start2:
				break;
			    else:
				overlap += int((end - start2).seconds)
		
		    if prev_start != None:
			intervals.append(int((start - prev_start).seconds))
		    
		    prev_start = start
		    prev_end = end
		return intervals, overlap

	    times = [(x[0], x[1]) for x in xen_domains.values()]
	    susp_intervals, susp_overlap = get_intervals_overlaps(times)

	    times = [(x[2], x[3]) for x in xen_domains.values()]
	    resm_intervals, resm_overlap = get_intervals_overlaps(times)
	    line = ",".join([localglobal,`mem`,`vmspernode`,`vms`, run]) + ","
	    if vmspernode == 1:
		avg_susp_interval = "NA"
		avg_resm_interval = "NA"
	    else:
		avg_susp_interval = avgstdev(susp_intervals)[0]
		avg_resm_interval = avgstdev(resm_intervals)[0]
	    line += ",".join([`x` for x in [suspend_time,susp_overlap,avg_susp_interval,resume_time,resm_overlap,avg_resm_interval]])
	    print >> xen_stats, line


	    xenlogf.close()

for k in keys:
    localglobal,mem,vmspernode = k
    vms = vmspernode * 4
    line = ",".join([localglobal,`mem`,`vmspernode`,`vms`])
    avg, stdev = avgstdev(susp[k])
    line += ",%.2f,%.2f" %(avg, stdev)
    avg, stdev = avgstdev(resm[k])
    line += ",%.2f,%.2f" %(avg, stdev)
    print >> xen_avg, line


xen_raw.close()
xen_avg.close()
xen_stats.close()